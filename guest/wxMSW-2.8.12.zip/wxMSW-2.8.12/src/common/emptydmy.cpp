// This file exists so that it can be compiled into an object so the linker
// will have something to chew on so that builds don't break when a platform
// lacks any objects in a particular multilib.
